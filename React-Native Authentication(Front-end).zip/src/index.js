// The Screens
export { default as LogIn } from './Screens/LogIn/LogIn';
export { default as Home } from './Screens/Home/Home';
export { default as SignUp } from './Screens/SignUp/SignUp';
export { default as Profile } from './Screens/Profile/Profile';