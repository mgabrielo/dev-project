export default {
    LOGIN: "LOGIN",
    SIGNUP: "SIGNUP"
}