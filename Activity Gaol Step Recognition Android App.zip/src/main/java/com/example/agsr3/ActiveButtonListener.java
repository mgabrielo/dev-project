package com.example.agsr3;

import android.widget.ImageButton;

public interface ActiveButtonListener {

        void onActBtn(GoalModal golModal, ImageButton active_btn);


}
