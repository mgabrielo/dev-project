package com.example.springbootangular.employmanager;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class EmployManagerApplication {

	public static void main(String[] args) {
		SpringApplication.run(EmployManagerApplication.class, args);
	}

}
