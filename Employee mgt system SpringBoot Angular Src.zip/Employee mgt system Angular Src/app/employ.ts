export class Employ {
    id:number =0  ;
    firstname:string = "";
    lastname:string= "";
    email:string ="";
}
