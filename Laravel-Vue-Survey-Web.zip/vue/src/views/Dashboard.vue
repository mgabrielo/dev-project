<template>
<PageComponent title="Dashboard">Content Goes Here</PageComponent> 
</template>



<script setup>
import PageComponent from '../components/PageComponent.vue';
</script>
