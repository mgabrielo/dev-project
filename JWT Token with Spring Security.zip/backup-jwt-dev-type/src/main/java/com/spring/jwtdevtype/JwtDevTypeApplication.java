package com.spring.jwtdevtype;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class JwtDevTypeApplication {

	public static void main(String[] args) {
		SpringApplication.run(JwtDevTypeApplication.class, args);
	}

}
