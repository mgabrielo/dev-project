package com.spring.jwtdevtype;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class JwtDevTypeApplicationTests {

	@Test
	void contextLoads() {
	}

}
