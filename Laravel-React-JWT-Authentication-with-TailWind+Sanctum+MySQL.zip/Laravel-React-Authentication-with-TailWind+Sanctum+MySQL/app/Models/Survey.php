<?php

namespace App\Models;

use Illuminate\Database\Eloquent\Model;
use Illuminate\Database\Eloquent\Factories\HasFactory;
use Cviebrock\EloquentSluggable\Sluggable;
use Spatie\Sluggable\HasSlug;
use Spatie\Sluggable\SlugOptions;


class Survey extends Model
{
    use HasFactory;
    use Sluggable;


    public $fillable = [
        'title', 'description', 'expire_date', 'image', 'user_id', 'status',
        'created_at', 'updated_at'
    ];


    public function sluggable(): array
    {
        return [
            'slug' => [
                'source' => 'title',
            ]
        ];
    }

    /**
     * Get the options for generating the slug.
     */
    // public function getSlugOptions() : getSlugOptions
    // {
    //     return getSlugOptions::create()
    //         ->generateSlugsFrom('name')
    //         ->saveSlugsTo('slug');
    // }

}
