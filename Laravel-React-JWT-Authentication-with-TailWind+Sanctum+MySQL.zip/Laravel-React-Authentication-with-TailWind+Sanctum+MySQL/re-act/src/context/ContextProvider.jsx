import { createContext, useContext, useState } from "react";

const state_context = createContext({
    currentUser: {},
    userToken: null,
    surveys:[],
    setCurrentUser: ()=>{},
    setUserToken:()=>{}
})

const tmpSurveys = [

]

export const ContextProvider = ({children})=>{

    const[currentUser, setCurrentUser] =useState({});

    const[userToken, _setUserToken] = useState(localStorage.getItem('TOKEN') || '')

    const [surveys, setSurveys] = useState(tmpSurveys)

    const setUserToken=(token)=>{
        if (token){
            localStorage.setItem('TOKEN',token)
        }else{
            localStorage.removeItem('TOKEN')
        }

        _setUserToken(token);
    }


    return(
        <state_context.Provider value={{
            currentUser,
            setCurrentUser,
            userToken,
            setUserToken,
            surveys
        }}>
            {children}
        </state_context.Provider>
    )
}

export const useStateContext=()=>useContext(state_context)