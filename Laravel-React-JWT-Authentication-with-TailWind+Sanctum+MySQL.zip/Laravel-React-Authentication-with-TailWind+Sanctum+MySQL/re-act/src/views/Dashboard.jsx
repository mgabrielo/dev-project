import PageComponent from "../components/PageComponent";


export default function Dashboard() {
  return (
    <PageComponent title="Dashboard">
        Children
    </PageComponent>
  )
}
