<template>

  <div class="container">
    <div class="row">
      <div class="col">
        <img src="../assets/loading-green.gif" alt="" class="d-block m-auto contact-img">
      </div>
    </div>
  </div>
</template>
    


<script>
  export default{
  name: 'SpinnerLoad'
  }
</script>


<style scoped>

</style>