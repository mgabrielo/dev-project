<template>
  <!-- <Spinner/> -->
 <NavBar/>
<router-view/>


</template>

<script>
  import NavBar from "@/components/Navbar";
  //import Spinner from "@/components/Spinner";
export default{
  name: 'App',
  components: { NavBar}
}

</script>
<style>

</style>
