<template>

  <div class="container mt-3">
    <div class="row">
      <div class="col">
        <p class="h3 text-success fw-bold">Edit Contact</p>
        <p class="card py-4 px-4 fst-italic mt-3">
          Vue can be installed directly on Windows or on the Windows Subsystem for Linux (WSL). We generally recommend that you install Vue on WSL if you are planning to interact with a NodeJS backend, want parity with a Linux production server, or plan to follow along with a tutorial that utilizes Bash commands
        </p>
      </div>
    </div>
  </div>

   <!-- loading spinner -->
 <div v-if="loading">
    <div class="container">
      <div class="row">
        <div class="col">
          <Spinner/>
        </div>
      </div>
    </div>
 </div>
<!-- error message -->
 <div v-if="!loading && errorMessage">
  <div class="container mt-3"> 
      <div class="row">
        <div class="col">
         <p class="h3 text-danger fw-bold">{{ errorMessage }}</p>
        </div>
      </div>
    </div>
 </div>

  
  <div class="container mt-3">
    <div class="row">
      <div class="col-md-5">
          <form @submit.prevent="updateSubmit">
            <div class="mb-2">
              <input v-model="contact.name" type="text" class="form-control" placeholder="name">
            </div>
            <div class="mb-2">
              <input v-model="contact.photo" type="text" class="form-control" placeholder="PhotoURL">
            </div>
            <div class="mb-2">
              <input v-model="contact.email" type="text" class="form-control" placeholder="Email">
            </div>
            <div class="mb-2">
              <input v-model="contact.mobile" type="number" class="form-control" placeholder="Mobile">
            </div>
            <div class="mb-2">
              <input v-model="contact.company" type="text" class="form-control" placeholder="Company">
            </div>
            <div class="mb-2">
              <input v-model="contact.title" type="text" class="form-control" placeholder="Title">
            </div>
            <div class="mb-2">
              <select  v-model="contact.groupId" class="form-control" v-if="groups.length > 0">
                <option value="">Select Group</option>
                <option :value="group.id" v-for="group of groups" :key="group.id">{{ group.name }}</option>
              </select>
            </div>
            <div class="d-flex justify-content-center mb-2 my-3">
              <button type="submit" class="btn btn-success btn-block"><i class="fa fa-check icon-adjust"></i><span>Update Contact</span></button>
            </div>
          </form>
      </div>
      <div class="col-md-4">
        <img :src="contact.photo" alt="" class="contact-img">
      </div>
    </div>
  </div>

  </template>
        
    
    
    <script>
    import { ContactService } from '@/services/ContactService';
    import Spinner from "@/components/Spinner";
      export default{
      name: 'EditContact',
      components: {Spinner},
      data: function(){
        return{
          contactId: this.$route.params.contactId,
          loading: false,
          contact: {
            name: '',
            photo: '',
            email: '',
            mobile: '',
            company: '',
            title: '',
            groupId: ''
          },
          groups: {},
          errorMessage: null
        }
      },
      created: async function() {
          try {
            this.loading =true;
            let response =await ContactService.getContact(this.contactId);
            let groupResponse = await ContactService.getAllgroups();
            this.contact = response.data;
            this.groups = groupResponse.data;
            this.loading =false;
          } catch (error) {
            this.loading =false;
            this.errorMessage =error;
          }
      },
      methods:{
        updateSubmit: async function(){
          try {
        let response = await ContactService.updateContact(this.contact, this.contactId);
        if(response){
            return this.$router.push('/');
        }else{
          return this.$router.push('/contacts/edit/${this.contactId}');
        }
      } catch (error) {
        console.log(error);
      }
        }
      }
      }
    </script>
    
    
    <style scoped>
    
    </style>