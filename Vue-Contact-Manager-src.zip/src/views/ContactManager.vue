<template>
 
<div class="container">
  <div class="row">
    <div class="col">
      <p class="h3 text-success fw-bold mt-3">Contact Manager
        <router-link to="/contacts/add" class="btn btn-outline-success btn-sm"><i class="fa fa-plus-circle"></i> Add New Contact</router-link>
      </p>
      <p class="card py-4 px-4 fst-italic mt-3">
        Vue can be installed directly on Windows or on the Windows Subsystem for Linux (WSL). We generally recommend that you install Vue on WSL if you are planning to interact with a NodeJS backend, want parity with a Linux production server, or plan to follow along with a tutorial that utilizes Bash commands
      </p>

      <form>
        <div class="row">
          <div class="col-3">
            <input type="text" class="form-control" placeholder="Search Name">
          </div>
          <div class="col-3">
            <input type="submit" class="btn btn-outline-dark"/>
          </div>
        </div>
      </form>
    </div>
  </div>
</div>
<!-- loading spinner -->
 <div v-if="loading">
    <div class="container">
      <div class="row">
        <div class="col">
          <Spinner/>
        </div>
      </div>
    </div>
 </div>
<!-- error message -->
 <div v-if="!loading && errorMessage">
  <div class="container mt-3"> 
      <div class="row">
        <div class="col">
         <p class="h3 text-danger fw-bold">{{ errorMessage }}</p>
        </div>
      </div>
    </div>
 </div>
<div class="container mt-3" v-if="contacts.length > 0">
  <div class="row">
    <div class="col-md-6" v-for ="contact of contacts" :key="contact">
        <div class="card my-2 list-group-item shadow-lg mb-3" style="background-color: #4d855c;" >
          <div class="card-body">
             <div class="row align-items-center">
              <div class="col-sm-3">
                  <img :src="contact.photo" alt=""
                  class="contact-img">
              </div>
              <div class="col-sm-7">    
                <ul class="list-group">
                  <li class="list-group-item">Name: <span class="fw-bold">{{ contact.name }}</span></li>
                  <li class="list-group-item">Email: <span class="fw-bold">{{ contact.email }}</span></li>
                  <li class="list-group-item">Mobile: <span class="fw-bold">{{ contact.mobile }}</span></li>
                </ul>
              </div>
              <div class="col-sm-2 mt-2">
                  <router-link :to="`/contacts/view/${contact.id}`">
                    <button  class="btn btn-warning my-1 btn-sm"><i class="fa fa-eye icon-adjust icon-adjust"></i>View</button> 
                  </router-link>

                  <router-link :to="`/contacts/edit/${contact.id}`" >
                    <button  class="btn btn-primary my-1 btn-sm "><i class="fa fa-edit icon-adjust-2"></i>Edit</button> 
                  </router-link>

                  <router-link to="/contacts/">
                   <button  class="btn btn-danger my-1 btn-sm" @click="clickDeleteContact(contact.id)"><i class="fa fa-trash icon-adjust"></i>Trash</button> 
                  </router-link>
              </div>
             </div>
          </div>
        </div>
    </div>
  </div>
</div>
</template>
    


<script>
import { ContactService } from '@/services/ContactService';
import Spinner from "@/components/Spinner";
  export default{
  name: 'ContactManager',
  components: {Spinner},
  data: function(){
    return{
      loading: false,
      contacts: [],
      errorMessage: null
    }
  },
  created: async function(){
    try {
      this.loading =true;
      let response = await ContactService.getAllContacts();
      this.contacts = response.data;
      this.loading =false;
    } catch (error) {
      this.errorMessage = error
      this.loading =false
    }
  },
  methods: {
    clickDeleteContact: async function(contactId){
      try {
        this.loading =true;
        let response =await ContactService.deleteContact(contactId);
       
        if(response){
         let response= await ContactService.getAllContacts();
        this.contacts = response.data
        this.loading =false;
        }else{
          this.loading =false
        }
      } catch (error) {
        this.errorMessage = error
        this.loading =false
      }
    }
  }

  }
</script>


<style scoped>

</style>