<!doctype html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1">
    <title>Student Mgt</title>
    <link href="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/css/bootstrap.min.css" rel="stylesheet" integrity="sha384-rbsA2VBKQhggwzxH7pPCaAqO46MgnOM80zW1RWuH61DGLwZJEdK2Kadq2F9CUG65" crossorigin="anonymous">
</head>

<body>
    <h1>Student Management System</h1>

    <script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.bundle.min.js" integrity="sha384-kenU1KFdBIe4zVF0s0G1M5b4hcpxyD9F7jL+jjXkk+Q2h455rYXK/7HAuoJl+0I4" crossorigin="anonymous"></script>


</body>

<div class="card-body m-3 ">
    <a href="{{ url('/create')}}" class="btn btn-success" title="Add Student"> Add Student</a>
</div>

@if($layout == 'index')
<div class="container-fluid">
    <div class="row">
        <section class="col">
            @include("studentlist")
        </section>
        <section class="col"></section>
    </div>
</div>
@elseif($layout == 'create')
<div class="container-fluid">
    <div class="row">
        <section class="col">
            @include("studentlist")
        </section>
        <section class="col">
            <form action="{{ url('/store')}}" method="post">
                @csrf
                <div class="form-group mb-3">
                    <label>CNE</label>
                    <input name="cne" type="text" class="form-control" placeholder="Enter CNE">
                </div>
                <div class="form-group mb-3">
                    <label>First Name</label>
                    <input name="firstname" type="text" class="form-control" placeholder="Enter First Name">
                </div>
                <div class="form-group mb-3">
                    <label>Second Name</label>
                    <input name="secondname" type="text" class="form-control" placeholder="Enter Second Name">
                </div>
                <div class="form-group mb-3">
                    <label>Age</label>
                    <input name="age" type="text" class="form-control" placeholder="Enter Age">
                </div>
                <div class="form-group mb-3">
                    <label>Specialty</label>
                    <input name="specialty" type="text" class="form-control" placeholder="Enter Specialty">
                </div>

                <div class="d-grid gap-5 d-md-flex justify-content-md-center">
                    <input type="submit" class="btn btn-info" value="Save">
                    <input type="reset" class="btn btn-warning" value="Reset">
                </div>
            </form>
        </section>
    </div>
</div>
@elseif($layout == 'show')
<div class="container-fluid">
    <div class="row">
        <section class="col">
            @include("studentlist")
        </section>
        <section class="col"></section>
    </div>
</div>
@elseif($layout == 'edit')
<div class="container-fluid">
    <div class="row">
        <section class="col">
            @include("studentlist")
        </section>
        <section class="col">
            <form action="{{url('/update/'.$student->id)}}" method="post">
                @csrf
                <div class="form-group mb-3">
                    <label>CNE</label>
                    <input value="{{ $student->cne}}" name="cne" type="text" class="form-control" placeholder="Enter CNE">
                </div>
                <div class="form-group mb-3">
                    <label>First Name</label>
                    <input value="{{ $student->firstname}}" name="firstname" type="text" class="form-control" placeholder="Enter First Name">
                </div>
                <div class="form-group mb-3">
                    <label>Second Name</label>
                    <input value="{{ $student->secondname}}" name="secondname" type="text" class="form-control" placeholder="Enter Second Name">
                </div>
                <div class="form-group mb-3">
                    <label>Age</label>
                    <input value="{{ $student->age}}" name="age" type="text" class="form-control" placeholder="Enter Age">
                </div>
                <div class="form-group mb-3">
                    <label>Specialty</label>
                    <input value="{{ $student->specialty}}" name="specialty" type="text" class="form-control" placeholder="Enter Specialty">
                </div>

                <div class="d-grid gap-5 d-md-flex justify-content-md-center">
                    <input type="submit" class="btn btn-info" value="Update">
                    <input type="reset" class="btn btn-warning" value="Reset">
                </div>
            </form>
        </section>
    </div>
</div>
@endif

<script src="https://cdn.jsdelivr.net/npm/@popperjs/core@2.11.6/dist/umd/popper.min.js" integrity="sha384-oBqDVmMz9ATKxIep9tiCxS/Z9fNfEXiDAYTujMAeBAsjFuCZSmKbSSUnQlmh/jp3" crossorigin="anonymous"></script>
<script src="https://cdn.jsdelivr.net/npm/bootstrap@5.2.3/dist/js/bootstrap.min.js" integrity="sha384-cuYeSxntonz0PPNlHhBs68uyIAVpIIOZZ5JqeqvYYIcEL727kskC66kF92t6Xl2V" crossorigin="anonymous"></script>

</html>