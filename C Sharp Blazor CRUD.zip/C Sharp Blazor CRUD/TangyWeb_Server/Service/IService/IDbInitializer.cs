﻿namespace TangyWeb_Server.Service.IService
{
    public interface IDbInitializer
    {
        void Initialize();
    }
}
