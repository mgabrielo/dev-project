package com.jwtdev.userrolemanagement;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class UserRoleManagementApplicationTests {

	@Test
	void contextLoads() {
	}

}
